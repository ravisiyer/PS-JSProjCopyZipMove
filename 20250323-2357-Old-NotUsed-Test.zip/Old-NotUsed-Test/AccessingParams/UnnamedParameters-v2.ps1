$param1=$args[0]
write-host "Parameter 1: " $param1