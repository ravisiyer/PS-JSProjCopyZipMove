param ($param1)
write-host $param1 