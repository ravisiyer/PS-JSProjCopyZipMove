$param1=$args[0]
write-host $param1