param ($param1="Param1DefaultValue")
write-host $param1 