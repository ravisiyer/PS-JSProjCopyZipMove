﻿"Hi there"
Write-Host "Hi there"